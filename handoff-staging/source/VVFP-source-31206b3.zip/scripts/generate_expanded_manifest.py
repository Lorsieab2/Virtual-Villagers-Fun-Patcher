"""Convert reviewed experimental-expansion logs into release patch data."""

from __future__ import annotations

import hashlib
import json
import struct
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
GAMES = ("vv3", "vv4", "vv5")
VV4_CURRENT_ORIGINS_SHR_OPERANDS = {
    "0x20902": {"before": "00807200", "after": "00A08500"},
    "0x20916": {"before": "00807200", "after": "00A08500"},
    "0x2092B": {"before": "00807200", "after": "00A08500"},
    "0x2B036": {"before": "00807200", "after": "00A08500"},
}
STOCK_SAVE_COMPATIBILITY = {
    "vv3": [
        {
            "offset": "0x28949",
            "before": "E852AAFDFF",
            "after": "E8632A0500",
            "purpose": "route expanded save loading through a stock-layout compatibility fallback",
        },
        {
            "offset": "0x28961",
            "before": "B9C74B0000",
            "after": "B92D690000",
            "purpose": "copy the complete expanded VV3 saved state after either load format succeeds",
        },
        {
            "offset": "0x7B3B1",
            "before": "00" * 102,
            "after": (
                "5589E551FF7510FF750CFF75088B4DFCE8DA7FF8FF84C07547"
                "FF7510681C2F0100FF75088B4DFCE8C37FF8FF84C0743056578B"
                "750881C6182F01008DBE98750000B914040000FDF3A5FC8B7D08"
                "81C7CC1E010031C0B9661D0000F3AB5F5EB00189EC5DC20C00"
            ),
            "purpose": "accept an exact stock VV3 save, move its saved-state tail, and zero the 106 inserted villager records",
        },
    ],
    "vv4": [
        {
            "offset": "0x1FC19",
            "before": "E8C23BFEFF",
            "after": "E8EF940600",
            "purpose": "route expanded save loading through a stock-layout compatibility fallback",
        },
        {
            "offset": "0x8910D",
            "before": "00" * 102,
            "after": (
                "5589E551FF7510FF750CFF75088B4DFCE8BEA6F7FF84C07547"
                "FF7510680C710100FF75088B4DFCE8A7A6F7FF84C0743056578B"
                "750881C6087101008DBEA86B0000B915040000FDF3A5FC8B7D08"
                "81C7B860010031C0B9EA1A0000F3AB5F5EB00189EC5DC20C00"
            ),
            "purpose": "accept an exact stock VV4 save, move its saved-state tail, and zero the 106 inserted villager records",
        },
    ],
    "vv5": [
        {
            "offset": "0x25709",
            "before": "E862E0FDFF",
            "after": "E85EEF0600",
            "purpose": "route expanded save loading through a stock-layout compatibility fallback",
        },
        {
            "offset": "0x9466C",
            "before": "00" * 102,
            "after": (
                "5589E551FF7510FF750CFF75088B4DFCE8EFF0F6FF84C07547"
                "FF751068787D0100FF75088B4DFCE8D8F0F6FF84C0743056578B"
                "750881C6747D01008DBEF0730000B919040000FDF3A5FC8B7D08"
                "81C7146D010031C0B9FC1C0000F3AB5F5EB00189EC5DC20C00"
            ),
            "purpose": "accept an exact stock VV5 save, move its saved-state tail, and zero the 106 inserted villager records",
        },
    ],
}
REVIEWED_RECORD_BOUNDS = {
    "vv3": [
        {
            "offset": "0x60D46",
            "before": "95000000",
            "after": "FF000000",
            "purpose": "expand the VV3 main-world villager hit-test reverse scan through record 255",
        },
        {
            "offset": "0x60D4C",
            "before": "706B1200",
            "after": "687B1F00",
            "purpose": "move the VV3 main-world villager hit-test endpoint from record 149 to record 255",
        },
        {
            "offset": "0x5F975",
            "before": "746B1200",
            "after": "6C7B1F00",
            "purpose": "move the VV3 mating spatial scan endpoint from record 149 to record 255",
        },
        {
            "offset": "0x5FA46",
            "before": "905C1200",
            "after": "807B1F00",
            "purpose": "move the VV3 nearby-villager helper endpoint from record 149 to record 255",
        },
        {
            "offset": "0x35A5A",
            "before": "96000000",
            "after": "00010000",
            "purpose": "expand the serialized villager-index validator from 150 to 256 records",
        },
        {
            "offset": "0x5EE69",
            "before": "96000000",
            "after": "00010000",
            "purpose": "expand the active-record lookup validator from 150 to 256 records",
        },
    ],
    "vv4": [
        {
            "offset": "0x66845",
            "before": "F7051B00",
            "after": "CF2A2E00",
            "purpose": "move the VV4 world-coordinate villager picker endpoint from record 149 to record 255",
        },
        {
            "offset": "0x66A15",
            "before": "C4051B00",
            "after": "9C2A2E00",
            "purpose": "move the VV4 player-to-player villager picker endpoint from record 149 to record 255",
        },
        {
            "offset": "0x66AE6",
            "before": "30E91A00",
            "after": "080E2E00",
            "purpose": "move the VV4 nearby sick-villager picker endpoint from record 149 to record 255",
        },
        {
            "offset": "0x66045",
            "before": "95000000",
            "after": "FF000000",
            "purpose": "expand the first reverse villager-selection scan through record 255",
        },
        {
            "offset": "0x66C9C",
            "before": "95000000",
            "after": "FF000000",
            "purpose": "expand the second reverse villager-selection scan through record 255",
        },
        {
            "offset": "0x6683F",
            "before": "95000000",
            "after": "FF000000",
            "purpose": "expand the third reverse villager-selection scan through record 255",
        },
        {
            "offset": "0x66A0F",
            "before": "95000000",
            "after": "FF000000",
            "purpose": "expand the fourth reverse villager-selection scan through record 255",
        },
    ],
    "vv5": [
        {
            "offset": "0x6FA75",
            "before": "10A40000",
            "after": "00180100",
            "purpose": "expand the compact-save loader span from 150 to 256 villager records",
        },
        {
            "offset": "0x6F955",
            "before": "95000000",
            "after": "FF000000",
            "purpose": "expand the first reverse villager-selection scan through record 255",
        },
        {
            "offset": "0x708FC",
            "before": "95000000",
            "after": "FF000000",
            "purpose": "expand the second reverse villager-selection scan through record 255",
        },
        {
            "offset": "0x71D77",
            "before": "95000000",
            "after": "FF000000",
            "purpose": "expand the third reverse villager-selection scan through record 255",
        },
        {
            "offset": "0x70280",
            "before": "DC821B00",
            "after": "04152F00",
            "purpose": "move the VV5 spatial-picker reverse scan endpoint from record 149 to record 255",
        },
        {
            "offset": "0x705E5",
            "before": "DC821B00",
            "after": "04152F00",
            "purpose": "move the first VV5 reverse-selection helper endpoint from record 149 to record 255",
        },
        {
            "offset": "0x70706",
            "before": "DC821B00",
            "after": "04152F00",
            "purpose": "move the second VV5 reverse-selection helper endpoint from record 149 to record 255",
        },
    ],
}


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest().upper()


def main() -> int:
    builds = json.loads((ROOT / "data" / "builds.json").read_text(encoding="utf-8-sig"))
    by_id = {game["id"]: game for game in builds["games"]}
    payload = {"format": 1, "games": {}}
    for game_id in GAMES:
        source = ROOT / "research" / "stock-executables" / by_id[game_id]["input_name"]
        prototype = ROOT / "research" / f"{game_id}-expanded-prototype.exe"
        edits = json.loads(
            (ROOT / "research" / f"{game_id}-expanded-prototype.json").read_text(
                encoding="utf-8"
            )
        )
        checksum_offset = struct.unpack_from("<I", source.read_bytes(), 0x3C)[0] + 24 + 64
        patches = []
        for edit in edits:
            if edit["offset"] == checksum_offset:
                continue
            offset = f"0x{edit['offset']:X}"
            patch = {
                "offset": offset,
                "before": struct.pack("<I", edit["old"]).hex().upper(),
                "after": struct.pack("<I", edit["new"]).hex().upper(),
                "purpose": edit["label"],
            }
            if game_id == "vv4" and offset in VV4_CURRENT_ORIGINS_SHR_OPERANDS:
                expected = VV4_CURRENT_ORIGINS_SHR_OPERANDS[offset]
                if patch["before"] != expected["before"] or patch["after"] != expected["after"]:
                    raise RuntimeError(
                        f"VV4 current-Origins .shr operand drift at {offset}: "
                        f"{patch['before']} -> {patch['after']}"
                    )
                patch["purpose"] = (
                    "relocate VV4 current-Origins .shr absolute operand "
                    "for expanded 256 mode"
                )
            patches.append(patch)
        patches.extend(STOCK_SAVE_COMPATIBILITY[game_id])
        patches.extend(REVIEWED_RECORD_BOUNDS[game_id])
        payload["games"][game_id] = {
            "source_sha256": sha256(source),
            "prototype_sha256": sha256(prototype),
            "patch_count": len(patches),
            "patches": patches,
        }
    destination = ROOT / "data" / "expanded_256.json"
    destination.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    print(f"Wrote {destination}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
