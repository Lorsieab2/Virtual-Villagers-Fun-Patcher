from __future__ import annotations

import hashlib
import json
import subprocess
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DOC = ROOT / "docs" / "appearance-upgrades-requirements.md"
BUILDS = ROOT / "data" / "builds.json"


class AppearanceUpgradeRequirementsTests(unittest.TestCase):
    def test_contract_contains_required_rules_and_stop_boundary(self) -> None:
        text = DOC.read_text(encoding="utf-8")
        required = [
            "Change Outfit belongs in the existing Villager Upgrades window",
            "exactly **5,000 tech points once**",
            "Change Head has the same selected active/living eligibility",
            "Warning: This will change",
            "young and old/gray head choice",
            "choices, in order, are exactly: Chief's mask, blue\nmask, red mask, orange mask, and no mask",
            "Play as the Heathens!",
            "defaults to\nthe blue Heathen mask",
            "Every current Heathen renders with no mask",
            "every native spawn",
            "Vanilla base-game save recognition is mandatory",
            "Executable growth is allowed",
            "remain **STOP** until independently proved",
            "do not authorize chooser-preview implementation",
        ]
        for phrase in required:
            with self.subTest(phrase=phrase):
                self.assertIn(phrase, text)
        self.assertIn("exactly **0** only when Play as the Heathens is active", text)
        self.assertIn("never write faction, type/tag, conversion", text)

    def test_contract_lists_exact_build_fingerprints(self) -> None:
        builds = json.loads(BUILDS.read_text(encoding="utf-8"))["games"]
        text = DOC.read_text(encoding="utf-8")
        for build in builds:
            with self.subTest(game=build["id"]):
                self.assertIn(f"{build['size']:,} bytes", text)
                self.assertIn(build["sha256"], text)

    def test_vv1_appearance_audit_is_exact_build_stop(self) -> None:
        text = DOC.read_text(encoding="utf-8")
        required = [
            "disassembly commit `8888682`",
            "record `+0x364`",
            "record `+0x360`",
            "RNG(19)",
            "RNG(20)",
            "Status/action 199",
            "clone path copies both",
            "sub_437790",
            "sub_449140 -> sub_437340",
            "`+0xAD34`",
            "Strange Berries",
            "Change Outfit and Change Head implementations remain ON HOLD",
            "exact save/load serializer mapping",
            "custom chooser/preview",
            "safe composable cave/new-section placement",
            "Do not\ninfer young/old catalogs",
        ]
        for phrase in required:
            with self.subTest(phrase=phrase):
                self.assertIn(phrase, text)
        self.assertIn("independent **STOP**", text)
        self.assertIn("1EC790B927741081D5CE13A48FB76983A4FD4336EA08F89317872643760AF03D", text)

    def test_vv2_appearance_audit_is_independent_exact_build_stop(self) -> None:
        text = DOC.read_text(encoding="utf-8")
        required = [
            "VV2 exact-build appearance audit",
            "724,992-byte build",
            "46C1503C209255C9CDEFA941DB2F449C8CF8E2CDD5C7D13CD975326E377ED677",
            "independent **STOP**",
            "record stride is `0xE48C`",
            "record `+0x54C`",
            "Native action 69 costs exactly **5,000 tech points**",
            "sub_4229D0",
            "sub_422890",
            "native range of `0..29`",
            "197,488 bytes",
            "not a final user catalog",
            "head/genetics DWORD candidate is record `+0x548`",
            "old/young resources",
            "genetics-warning callback",
            "head feels strange",
            "no direct caller xref",
            "vanilla-save compatibility",
            "requested Change Outfit and Change Head implementations\nremain ON HOLD for VV2",
        ]
        for phrase in required:
            with self.subTest(phrase=phrase):
                self.assertIn(phrase, text)

    def test_vv3_change_outfit_audit_is_exact_build_stop(self) -> None:
        text = DOC.read_text(encoding="utf-8")
        required = [
            "VV3 Change Outfit exact-build audit",
            "a9d3b1ff0e223c0aa5fd8504194845afa4456df1",
            "831,488-byte build",
            "8BC5DB382D02BC5C21AD5F607580D60FF44A6519CC7EB133F03113BAACAE6503",
            "independent **STOP**",
            "The Clothing Hut",
            "Choose\nan outfit for your villager!",
            "Do you want to spend 5000 tech points to change\nthis villager's clothes?",
            "Getting new clothes!",
            "Not enough tech points\nto make new clothes!",
            "Male/female body resources",
            "young/old head assets",
            "sub_4227F0",
            "sub_4228F0",
            "literal `0x1388` (5,000)",
            "0x004228A2`/`0x228A2",
            "[eax+0x12FB0]",
            "does **not** prove a clothing purchase",
            "selected-villager identity",
            "outfit-field write",
            "Change Outfit remains ON HOLD",
            "sex/age/special/invalid catalog classification",
            "world, Detail, and chooser",
            "stock and expanded-256 layouts",
            "this audit is Outfit-only",
            "special\nconstructor value `29` is outside",
            "chooser accepts exactly `0..28`",
            "there is no rollback snapshot",
        ]
        for phrase in required:
            with self.subTest(phrase=phrase):
                self.assertIn(phrase, text)

    def test_all_five_change_outfit_audits_are_separate_and_on_hold(self) -> None:
        text = DOC.read_text(encoding="utf-8")
        citations = (
            "8888682",
            "ed4cedb5a0d41b28319bf62b8d25596baa3e7a2e",
            "a9d3b1ff0e223c0aa5fd8504194845afa4456df1",
            "23fee766bfbcccc634c565c6bc88f3318e30f244",
            "313651623d2687d3f53ce5cc30c9f5ad07051a8d",
        )
        for citation in citations:
            self.assertIn(citation, text)
        for game in ("VV1", "VV2", "VV3", "VV4", "VV5"):
            self.assertIn(game, text)
        for marker in (
            "Change Outfit remains ON HOLD",
            "requested Change Outfit and Change Head implementations\nremain ON HOLD for VV2",
            "VV4 Change Outfit exact-build audit",
            "VV5 Change Outfit exact-build audit",
            "no custom Change Outfit implementation is authorized",
            "0x46CEC7`/`0x46CED1",
            "button `+0x50`",
            "`0x419E8E`",
            "`0x419E94`/`0x419E9E`",
        ):
            self.assertIn(marker, text)

    def test_all_five_change_head_audits_are_separate_on_hold_and_heathen_safe(self) -> None:
        text = DOC.read_text(encoding="utf-8")
        citations = (
            "ccb5d973909faf222745968cca15109654f767f4",
            "bfd2ad7f07efa730d962787149c1348f2a6c336b",
            "cdf50e399360c1eba04449d359b0d477573b7361",
            "9dd368fe6248c55f53be9a620025e2a655854ddd",
            "388bf9a4e3ee400ba7168317526e9511c77a1048",
        )
        for citation in citations:
            self.assertIn(citation, text)
        for marker in (
            "Change Head exact-build evidence (all five ON HOLD)",
            "### VV1",
            "### VV2",
            "### VV3",
            "### VV4",
            "### VV5",
            "record+0x360",
            "record+0x548",
            "record+0xDF0",
            "record+0x1BB8",
            "current faction `+0x1CEC`",
            "no current Heathen may open",
            "converted former Heathen",
            "sub_419D80",
            "No native Change Head chooser",
            "head-specific 5,000 transaction",
            "no UI row, manifest feature, helper, runtime bytes, or output",
        ):
            self.assertIn(marker, text)

    def test_vv5_mask_system_is_exact_build_stop(self) -> None:
        text = DOC.read_text(encoding="utf-8")
        required = [
            "VV5 mask-system exact-build audit (STOP)",
            "disassembly commit `870d236`",
            "991,232-byte build",
            "92946781980220E9D1A2E6C573925519934608F5215F4A0F8CE3B90088C5C65D",
            "current faction byte is record `+0x1CEC`",
            "generic selector bytes are\n`+0x1CED` and `+0x1CEE`",
            "`+0x1CEF` is a persisted but currently unconsumed\nsidecar",
            "type dword is `+0x1CFC`",
            "blue `0`, orange `1`, red `2`, purple `3`, and Chief `4`",
            "mask overlay\nis gated by current faction",
            "Reset, spawn, conversion, clone, and save/load\nbehavior are mapped",
            "stock Detail portrait has no mask overlay",
            "`Give Heathen Mask` remains **STOP**",
            "native chooser/cost and\nselected-active-living-current-believer/no-charge-Heathen transaction",
            "safe\nmanual encoding",
            "Detail overlay/refresh",
            "collision-free stock+expanded-256\nplacement",
            "`Play as the Heathens!` remains **STOP**",
            "complete\nall-spawn Play interception",
            "Neither feature is registered or\nadvertised",
            "changes no manifests,\ngenerators, companion DLL, outputs, prices, save behavior, or executable\npayloads",
        ]
        for phrase in required:
            with self.subTest(phrase=phrase):
                self.assertIn(phrase, text)

    def test_no_loaded_fun_patch_advertises_unimplemented_appearance_options(self) -> None:
        import sys

        sys.path.insert(0, str(ROOT / "src"))
        from vv_fun_patcher import load_fun_patches  # noqa: PLC0415

        forbidden = {
            "change outfit",
            "change head",
            "give heathen mask",
            "play as the heathens!",
        }
        for patch in load_fun_patches():
            self.assertNotIn(patch.id.casefold(), forbidden)
            self.assertNotIn(patch.name.casefold(), forbidden)
            self.assertNotIn("change outfit", patch.description.casefold())
            self.assertNotIn("change head", patch.description.casefold())
            self.assertNotIn("give heathen mask", patch.description.casefold())
            self.assertNotIn("play as the heathens!", patch.description.casefold())

    def test_release_manifest_includes_contract(self) -> None:
        text = (ROOT / "scripts" / "build_release.py").read_text(encoding="utf-8")
        self.assertIn('"docs/appearance-upgrades-requirements.md"', text)

    def test_existing_executable_manifests_are_unchanged_from_parent_commit(self) -> None:
        manifest_paths = sorted(ROOT.glob("data/*_origins_feature.json"))
        manifest_paths += sorted(ROOT.glob("data/*_origins_village_wide_upgrades.json"))
        try:
            parent = subprocess.run(
                ["git", "rev-parse", "HEAD"],
                cwd=ROOT,
                check=True,
                capture_output=True,
                text=True,
            ).stdout.strip()
        except (OSError, subprocess.CalledProcessError):
            self.skipTest("git parent unavailable for executable-manifest snapshot")
        for path in manifest_paths:
            relative = path.relative_to(ROOT).as_posix()
            before = subprocess.run(
                ["git", "show", f"{parent}:{relative}"],
                cwd=ROOT,
                check=True,
                capture_output=True,
                text=True,
            ).stdout
            current_manifest = json.loads(path.read_text(encoding="utf-8"))
            before_manifest = json.loads(before)
            executable_keys = (
                "patches",
                "output_tag",
                "running_preference_id",
                "running_preference_evidence",
            )
            if relative.endswith("_origins_village_wide_upgrades.json"):
                # The five village-wide payloads are intentionally corrected
                # in the current slice. Their guards and ownership metadata
                # remain unchanged; only their generated payload bytes differ.
                current_patch = current_manifest["patches"][0]
                before_patch = before_manifest["patches"][0]
                for patch_key in ("offset", "before", "purpose"):
                    self.assertEqual(
                        current_patch.get(patch_key),
                        before_patch.get(patch_key),
                        f"{relative}:patches[0].{patch_key}",
                    )
                continue
            if relative == "data/vv5_origins_feature.json":
                # VV5's stock Food Doubler wrapper/menu is the intentional
                # runtime change in this slice.  Keep all other manifest
                # identity/runtime fields frozen against the clean parent.
                executable_keys = (
                    "output_tag",
                    "running_preference_id",
                    "running_preference_evidence",
                )
            for key in executable_keys:
                self.assertEqual(current_manifest.get(key), before_manifest.get(key), f"{relative}:{key}")
            self.assertEqual(
                current_manifest["companion_files"][0]["source"],
                before_manifest["companion_files"][0]["source"],
                f"{relative}:companion_files.source",
            )
            self.assertEqual(
                current_manifest["companion_files"][0]["destination"],
                before_manifest["companion_files"][0]["destination"],
                f"{relative}:companion_files.destination",
            )
            actual_companion = hashlib.sha256(
                (ROOT / "assets/origins/VVFP Origins Icons.dll").read_bytes()
            ).hexdigest().upper()
            self.assertEqual(current_manifest["companion_files"][0]["sha256"], actual_companion)


if __name__ == "__main__":
    unittest.main()
